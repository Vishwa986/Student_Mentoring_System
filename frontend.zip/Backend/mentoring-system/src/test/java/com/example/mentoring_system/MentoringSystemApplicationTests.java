package com.example.mentoring_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentoringSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
